package com.poulamee.JourneyStay.entity;


import com.poulamee.JourneyStay.entity.enums.Role;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Set;

@Entity
@Getter
@Setter
@Table(name = "app_user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String email;

    @Column(nullable = false)
    private String password; //encoded

    private String name;

    @ElementCollection(fetch = FetchType.EAGER)  // collection of data for a single attribute
    @Enumerated(EnumType.STRING) // link the enum
    private List<Role> roles; //Role is enum
}

